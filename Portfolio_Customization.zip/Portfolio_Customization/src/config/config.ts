export const config  = {
    
    bucket_name: "angular_boilerplate",
    bucket_slug: "angular-boilerplate",
    bucket_id: "5d21cf97e661c82fe6b78205",
    read_key: "dGdDziXsMPrgOCEOaPY4yZWb6uWyftdq9lPDSxwDfZsXhjjLr3",
    write_key: "BN1X435r0zT1BNlKGqRPBc6UQGTpYgtu95gopKrZ85B2PdFN9E",
    url: "https://api.cosmicjs.com/v1/"
    
    }
