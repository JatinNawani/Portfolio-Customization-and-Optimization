export class User {
    constructor(
        // tslint:disable-next-line: no-trailing-whitespace

        public age: number,
        public dependents: number,
        public salary: number,
        public savings: number,
        public expense: number
    ) {}
}
